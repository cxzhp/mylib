#include<simple_layers/simple_layer.h>
#include <pluginlib/class_list_macros.h>

PLUGINLIB_EXPORT_CLASS(simple_layer_namespace::SimpleLayer, costmap_2d::Layer)


using costmap_2d::LETHAL_OBSTACLE;

#define CLEANED_VALUE 123  //123

namespace simple_layer_namespace
{

SimpleLayer::SimpleLayer() {}

void SimpleLayer::onInitialize()
{
  ros::NodeHandle nh("~/" + name_);
  current_ = true;

  dsrv_ = new dynamic_reconfigure::Server<costmap_2d::GenericPluginConfig>(nh);
  dynamic_reconfigure::Server<costmap_2d::GenericPluginConfig>::CallbackType cb = boost::bind(
      &SimpleLayer::reconfigureCB, this, _1, _2);
  dsrv_->setCallback(cb);

}


void SimpleLayer::reconfigureCB(costmap_2d::GenericPluginConfig &config, uint32_t level)
{
  enabled_ = config.enabled;
}

void SimpleLayer::updateBounds(double robot_x, double robot_y, double robot_yaw, double* min_x,
                                           double* min_y, double* max_x, double* max_y)
{

  if (!enabled_)
    return;

  mark_x_ = robot_x;
  mark_y_ = robot_y;
  ROS_INFO("==== current_pos. x:%f y:%f",mark_x_,mark_y_);

  *min_x = std::min(*min_x, mark_x_);
  *min_y = std::min(*min_y, mark_y_);
  *max_x = std::max(*max_x, mark_x_);
  *max_y = std::max(*max_y, mark_y_);
}

void SimpleLayer::updateCosts(costmap_2d::Costmap2D& master_grid, int min_i, int min_j, int max_i,
                                          int max_j)
{
  if (!enabled_)
    return;

  unsigned int mx;
  unsigned int my;

  unsigned int mlastX=0;
  unsigned int mlastY=0;

  if(master_grid.worldToMap(mark_x_, mark_y_, mx, my)){

    //test
    //time_t tt = time(0);
    //tm* t = localtime(&tt);
    //ROS_INFO("==== current_time. sec:%d",t->tm_sec);
    //if(t->tm_sec % 10 ==1 || t->tm_sec % 10 ==2 ||t->tm_sec % 10 ==3)
    //{
    //    ros::NodeHandle nh;
    //    ros::ServiceClient clientClearCostmap = nh.serviceClient<std_srvs::Empty>("movebase/clear_costmaps");
    //    std_srvs::Empty emptySrv;
    //    clientClearCostmap.call(emptySrv);
    //    
    //    master_grid.setCost(mx, my, LETHAL_OBSTACLE);
    //    ROS_INFO("==== clear. sec:%d",t->tm_sec);
    //    return ;
    //}
    //ROS_INFO("==== not in clear.");


    //ROS_INFO("==== clear. flagPublicCLeanedPath_:%d",flagPublicCLeanedPath_?1:0);

    if(flagPublicCLeanedPath_ == false)
    {
        //ROS_INFO("==== flagPublicCLeanedPath_:%d",flagPublicCLeanedPath_?1:0);
        return ;
    }

    //cleanedXY_.insert(std::make_pair(mx,my));
    //
    //for (auto it = cleanedXY_.begin(); it != cleanedXY_.end(); ++it){
    //    //master_grid.setCost(it->first, it->second, LETHAL_OBSTACLE);
    //    //master_grid.setCost(it->first, it->second, CLEANED_VALUE);
    //    fillCleanedCost(master_grid,it->first, it->second);
    //}

    //ROS_INFO("==== cleanedPath.push_back. mx:%d my:%d mlastMX_:%d mlastMY_:%d",mx,my,mlastMX_,mlastMY_);
    if(mx != mlastMX_ && my != mlastMY_)
    {
        cleanedPath.push_back(std::make_pair(mx,my));
        //ROS_INFO("==== cleanedPath.push_back. x:%d y:%d",mx,my);
    }

    

    for(cleanedPathIterator=cleanedPath.begin(); cleanedPathIterator!=cleanedPath.end(); cleanedPathIterator++)
    {
        //ROS_INFO("==== cleanedPath. x:%d y:%d",cleanedPathIterator->first, cleanedPathIterator->second);
        fillCleanedCost(master_grid,cleanedPathIterator->first, cleanedPathIterator->second,mlastX,mlastY);
        mlastX = cleanedPathIterator->first;
        mlastY = cleanedPathIterator->second;
    }


    mlastMX_ = mx;
    mlastMY_ = my;
  }

}


void SimpleLayer::reset()
{
    if(flagPublicCLeanedPath_ == true)
    {
        flagPublicCLeanedPath_ = false;
        ROS_INFO("SimpleLayer::reset. publishCLeanedPath:%s",flagPublicCLeanedPath_?"true":"false");
    }else{
        flagPublicCLeanedPath_ = true;
        ROS_INFO("SimpleLayer::reset. publishCLeanedPath:%s",flagPublicCLeanedPath_?"true":"false");
    }
    
}


void SimpleLayer::fillCleanedCost(costmap_2d::Costmap2D& master_grid, int x, int y, int lastX, int lastY)
{

    if(lastX == 0 and lastY == 0)
    {
        return;
    }

    std::list< std::pair<int,int> > line,lineForward;
    ROS_INFO("==== fillCleanedCost. x:%d y:%d", x, y);
    ROS_INFO("==== fillCleanedCost. lastX:%d lastY:%d", lastX, lastY);




    //goback
    line = getLine(x,y,lastX,lastY);
    std::list< std::pair<int,int> >::iterator iter;//iterator

    for(iter=line.begin(); iter!=line.end(); iter++)
    {
        ROS_INFO("==== line. x:%d y:%d", iter->first, iter->second);
        //master_grid.setCost(iter->first, iter->second, LETHAL_OBSTACLE);
        fillCleanedCostwithNeighbor(master_grid,iter->first, iter->second);
    }


    //int xOffset = 2;
    //int yOffset = 3;
    //int yOffsetStart = -3;

    //for(int i=0; i<=xOffset; ++i)
    //{
    //    for(int j=yOffsetStart; j<=yOffset; ++j)
    //    {
    //        master_grid.setCost(x+i, y+j, LETHAL_OBSTACLE);
    //    }
    //}

}


void SimpleLayer::fillCleanedCostwithNeighbor(costmap_2d::Costmap2D& master_grid, int x, int y)
{

    int xOffset = 2;
    int yOffset = 3;
    int yOffsetStart = -3;

    for(int i=0; i<=xOffset; ++i)
    {
        for(int j=yOffsetStart; j<=yOffset; ++j)
        {
            master_grid.setCost(x+i, y+j, LETHAL_OBSTACLE);
        }
    }

}


std::list< std::pair<int,int> > SimpleLayer::getLine(int x0, int y0, int x1, int y1)
{

    return bresenham(x0,y0,x1,y1);
    //std::list< std::pair<int,int> > listLine;

    //int dx = fabs(x0-x1);
    //int dy = fabs(y0-y1);
    //int y = y0;
    //int e = -2*dx;
    //for(int x=x0; x<=x1; ++x){
    //    listLine.push_back(std::make_pair(x,y));
    //    //ROS_INFO("==== listLine.push_back. x:%d y:%d", x, y);
    //    e += 2*dy;
    //    if(e>0) ++y;
    //    if(e>=dx) e -= 2*dx;
    //}

    //return listLine;
}


// Code from https://github.com/miloyip/line/blob/master/line_bresenham.c
// Modified from  https://rosettacode.org/wiki/Bitmap/Bresenham%27s_line_algorithm#C
//Bresenham algorithm
std::list< std::pair<int,int> > SimpleLayer::bresenham(int x0, int y0, int x1, int y1) {
    std::list< std::pair<int,int> > listLine;

    int dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
    int dy = abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
    int err = (dx > dy ? dx : -dy) / 2;

    while (listLine.push_back(std::make_pair(x0,y0)), x0 != x1 || y0 != y1) {
        int e2 = err;
        if (e2 > -dx) { err -= dy; x0 += sx; }
        if (e2 <  dy) { err += dx; y0 += sy; }
    }

    return listLine;
}



} // end namespace
